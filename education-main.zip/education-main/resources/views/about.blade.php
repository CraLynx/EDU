@extends('layouts.app')
@section('title', 'О нас')

@section('content')
    ЗДЕСЬ Я РАССКАЖУ О СЕБЕ, MOTHER FUCKER!!!
@endsection
